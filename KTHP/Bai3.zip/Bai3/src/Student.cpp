#include "Student.h"


Student::Student(string id, string fullName, string dateOfBirth, string statics, string nump, string email, double dtb)
{
    //ctor
    this->id = id;
    this->fullName = fullName;
    this->dateOfBirth = dateOfBirth;
    this->statics = statics;
    this->nump = nump;
    this->email = email;
    this->dtb = dtb;
}

Student::~Student()
{
    //dtor
}
