#include <iostream>
#include"BST.h"
#include"Node.h"
#include"Student.h"
using namespace std;

int main()
{
    BST t;
    t.inputStudentList(t.getRoot());
    return 0;
}
