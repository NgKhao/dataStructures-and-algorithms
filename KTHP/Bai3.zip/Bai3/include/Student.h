#ifndef STUDENT_H
#define STUDENT_H
#include<string>
using namespace std;

class Student
{
    public:
        Student();
        Student(string id, string fullName, string dateOfBirth, string statics, string nump, string email, double dtb);
        virtual ~Student();
        string getId(){ return id;}
//        void setFullName(string f){ fullName = f;}
        string getFullName(){ return fullName;}
        string getDateOfBirth(){ return dateOfBirth;}
        string getStatics(){ return statics;}
        string getNump(){ return nump;}
        string getEmail(){return email;}
        double getDtb(){ return dtb;}

    protected:

    private:
        string id;
        string fullName;
        string dateOfBirth;
        string statics; // tình trạng
        string nump;
        string email;
        double dtb;
};

#endif // STUDENT_H
